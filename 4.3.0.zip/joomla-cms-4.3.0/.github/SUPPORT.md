Where can you get support and help?
====================
* [The Joomla! Documentation](https://docs.joomla.org/Special:MyLanguage/Main_Page).
* [Frequently Asked Questions](https://docs.joomla.org/Special:MyLanguage/Category:FAQ) (FAQ).
* Find the [information you need](https://docs.joomla.org/Special:MyLanguage/Start_here).
* Find [help and other users](https://www.joomla.org/about-joomla/create-and-share.html).
* Post questions at [our forums](https://forum.joomla.org).
* [Joomla Resources Directory](https://community.joomla.org/service-providers-directory/) (JRD).
